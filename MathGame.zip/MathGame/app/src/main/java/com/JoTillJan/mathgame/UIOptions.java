package com.JoTillJan.mathgame;

import android.view.View;
import android.view.Window;

public class UIOptions {

    /**
     * when used hides notification and navigation bar
     */
    static int STANDARD_UI_OPTIONS = View.SYSTEM_UI_FLAG_FULLSCREEN;

}


